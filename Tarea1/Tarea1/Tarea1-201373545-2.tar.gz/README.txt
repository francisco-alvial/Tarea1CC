Las librerias usadas son:
-sympy
-numpy
-matplotlib.pyplot
-ipywidgets


Nombre estudiante : Francisco Alvial
Rol: 2013735345-2